package modul2;

public class Pegawai {
	String nama ;
	int nip;
	double gaji;
	
	public String setNama(String beriNama){
		return this.nama = beriNama;
	}
	public int setNomor(int beriNomor){
		return this.nip = beriNomor;
	}
	public double setGaji(double beriGaji){
		return this.gaji = beriGaji;
	}
	public void infoHasil(){
		System.out.println(
				"Nama = "+nama+"\n"+
				"NIP = "+nip+"\n"+
				"Gaji = Rp."+gaji+"\n"+
				"------------------------"
		);
	}
	
	public static void main(String[]args){
		Pegawai hasil1 = new Pegawai();
		Pegawai hasil2 = new Pegawai();
		Pegawai hasil3 = new Pegawai();
		Pegawai hasil4 = new Pegawai();
		Pegawai hasil5 = new Pegawai();
		
		hasil1.setNama("Fulana");
		hasil2.setNama("Fulani");
		hasil3.setNama("Fulanu");
		hasil4.setNama("Fulane");
		hasil5.setNama("Fulano");
		
		hasil1.setNomor(110);
		hasil2.setNomor(111);
		hasil3.setNomor(112);
		hasil4.setNomor(113);
		hasil5.setNomor(114);
		
		hasil1.setGaji(100000);
		hasil2.setGaji(100000);
		hasil3.setGaji(200000);
		hasil4.setGaji(150000);
		hasil5.setGaji(100000);
		
		hasil1.infoHasil();
		hasil2.infoHasil();
		hasil3.infoHasil();
		hasil4.infoHasil();
		hasil5.infoHasil();
		
	}
}
