package modul2;

public class Bicycle {
	int Cadance ;
	int Speed ;
	int Gear ;
	
	void changeCadance(int setCadance){
		Cadance = setCadance ;
		return ;
	}
	
	void speedUp(int setSpeed){
		Speed = setSpeed ;
	}
	
	void changeGear(int setGear){
		Gear = setGear ;
	}
	
	void printInfo(){
		System.out.println();
	}
	
}
