package modul2;

public class BicycleDemo {
	public static void main(String[] args){
		Bicycle bike1 = new Bicycle();
		Bicycle bike2 = new Bicycle();
		
		bike.
	}
}
