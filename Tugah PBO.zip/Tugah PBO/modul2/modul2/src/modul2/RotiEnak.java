package modul2;

public class RotiEnak {
	public static void main(String[]args){
		Rotiku rotienak = new Rotiku();
		rotienak.timbangBerat(50);
		rotienak.beriWarna("Cokelat");
		rotienak.beriRasa("Pisang Cokelat");
		rotienak.hargaJual(5000);
		rotienak.infoRoti();
	}
}
