package modul2;

public class TugasRumah {
	int nilaiUTS, nilaiTugas, nilaiUAS;
	double nUTS, nTugas, nUAS, nilaiTotal;
	
	public void nilai(int uts, int tgs, int uas){
		this.nilaiUTS = uts;
		this.nilaiTugas = tgs;
		this.nilaiUAS = uas;
		this.nUTS = nilaiUTS * 1.0;
		this.nTugas  = nilaiTugas * 1.0;
		this.nUAS = nilaiUAS * 1.0;
		
	}
	
	public void infoNilai(){
		nilaiTotal = (nUTS + nTugas + nUAS)/3 ;
		System.out.println(
				"Nilai UTS = "+nUTS+"\n"+
				"Nilai Tugas = "+nTugas+"\n"+
				"Nilai UAS = "+nUAS+"\n"+
				"Total Nilai = "+nilaiTotal);
	}
	
	public static void main(String[]args){
		TugasRumah na = new TugasRumah();
		na.nilai(70, 80, 90);
		na.infoNilai();
	}
}
