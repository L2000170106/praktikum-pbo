import java.awt.*;
import javax.swing.*;

public class Soal1 extends JPanel{
	public Soal1(){
		setLayout(new FlowLayout());
		
		JLabel tx1 = new JLabel("Timur");
		JLabel tx2 = new JLabel("Barat");
		JLabel tx3 = new JLabel("Utara");
		JLabel tx4 = new JLabel("Selatan");
		JLabel tx5 = new JLabel("Pusat");
		
		tx1.setBackground(Color.red);
		tx2.setBackground(Color.blue);
		tx3.setBackground(Color.green);
		tx4.setBackground(Color.yellow);
		tx5.setBackground(Color.pink);
		
		tx1.setOpaque(true);
		tx2.setOpaque(true);
		tx3.setOpaque(true);
		tx4.setOpaque(true);
		tx5.setOpaque(true);
		
		add(tx1);
		add(tx2);
		add(tx3);
		add(tx4);
		add(tx5);
	}
}
