import java.awt.*;
import javax.swing.*;

public class Soal2 extends JPanel{
	public Soal2(){
		setLayout (new BorderLayout());
		
		JLabel b1 =  new JLabel("Pusat");
		JLabel b2 =  new JLabel("Utara");
		JLabel b3 =  new JLabel("South");
		JLabel b4 =  new JLabel("Barat");
		JLabel b5 =  new JLabel("Timur");
		
		b1.setBackground(Color.orange);
		b2.setBackground(Color.green);
		b3.setBackground(Color.yellow);
		b4.setBackground(Color.blue);
		b5.setBackground(Color.red);
		
		b1.setOpaque(true);
		b2.setOpaque(true);
		b3.setOpaque(true);
		b4.setOpaque(true);
		b5.setOpaque(true);
		
		add(b1, BorderLayout.CENTER);
		add(b2, BorderLayout.NORTH);
		add(b3, BorderLayout.SOUTH);
		add(b4, BorderLayout.EAST);
		add(b5, BorderLayout.WEST);
		
	}	
}

