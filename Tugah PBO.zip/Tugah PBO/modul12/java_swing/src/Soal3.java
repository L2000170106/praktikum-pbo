import java.awt.*;
import javax.swing.*;

public class Soal3 extends JPanel {
	public Soal3(){
		setLayout (new GridLayout(2, 3, 2, 2));
		
		JLabel b1 =  new JLabel("Barat");
		JLabel b2 =  new JLabel("Timur");
		JLabel b3 =  new JLabel("Utara");
		JLabel b4 =  new JLabel("Selatan");
		JLabel b5 =  new JLabel("Pusat");
		
		b1.setBackground(Color.orange);
		b2.setBackground(Color.green);
		b3.setBackground(Color.yellow);
		b4.setBackground(Color.blue);
		b5.setBackground(Color.red);
		
		b1.setOpaque(true);
		b2.setOpaque(true);
		b3.setOpaque(true);
		b4.setOpaque(true);
		b5.setOpaque(true);
		
		add(b1);
		add(b2);
		add(b3);
		add(b4);
		add(b5);
	}
}
