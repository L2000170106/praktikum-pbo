import javax.swing.JFrame;
import javax.swing.JTabbedPane;

public class Execute {

	public static void main(String[] args){
		JFrame Frame = new JFrame();
		Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JTabbedPane tp = new JTabbedPane();
		tp.add("Soal 1", new Soal1());
		tp.add("Soal 2", new Soal2());
		tp.add("Soal 3", new Soal3());
		
		Frame.getContentPane().add(tp);
		Frame.pack();
		Frame.setVisible(true);
	}
}
