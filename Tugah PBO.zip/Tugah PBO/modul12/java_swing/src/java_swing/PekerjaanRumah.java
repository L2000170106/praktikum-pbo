package java_swing;

import java.awt.*;
import javax.swing.*;

public class PekerjaanRumah extends JFrame{
	public PekerjaanRumah(){
		
	}
}
	