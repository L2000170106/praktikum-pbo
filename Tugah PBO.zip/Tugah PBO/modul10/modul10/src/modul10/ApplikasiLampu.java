package modul10;

import java.util.Scanner;

public class ApplikasiLampu {
	public static void main(String[] args){
		Lampu lampu = new Lampu();
		Scanner sc = new Scanner(System.in);
		lampu.statusLampu = lampu.setSaklar(0);
		System.out.println("Status lampu = "+lampu.statusLampu+"\nketikkan");
		System.out.println("1 untuk Menyalakan Lampu\n0 untuk mematikan lampu");
		while(lampu.statusLampu < 3){
			if(lampu.setSaklar(sc.nextInt()) == 0){
				lampu.matikanLampu();
				// mematikan lampu
				if(lampu.setSaklar(sc.nextInt()) == 0){
					lampu.matikanLampu();
				}
				// menghidupkan lampu
				else{
					lampu.hidupkanLampu();
				}
			}else{
				lampu.hidupkanLampu();
				// menghidupkan lampu
					if(lampu.setSaklar(sc.nextInt()) == 0){
						lampu.hidupkanLampu();// masih hidup
						if(lampu.setSaklar(sc.nextInt()) == 0 ){
							lampu.hidupkanLampu();
						}
						else{
							lampu.matikanLampu();
						}
					}
					else{
						lampu.matikanLampu();
					}
			}
			lampu.statusLampu++;
		}
	}
}
