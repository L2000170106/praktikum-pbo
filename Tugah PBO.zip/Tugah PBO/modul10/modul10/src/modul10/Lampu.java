package modul10;

public class Lampu implements IntLampu {
	public int statusLampu;
	public void matikanLampu(){
		if(statusLampu == 0){
			System.out.println("Lampu sudah dalam kondisi mati");
		}else if(statusLampu == 1){
			statusLampu =- 1;
			System.out.println("Lampu sudah dimatikan");
		}
	}
	public void hidupkanLampu(){
		if(statusLampu == 1){
			System.out.println("Lampu sudah dinyalakan");
		}else{
			statusLampu =- 1;
			System.out.println("Lampu sudah dalam kondisi menyala");
		}
	}
	public void redupkanLampu(){
		if(statusLampu == 2){
			System.out.println("Lampu sudah redup");
		}else{
			statusLampu =- 1;
			System.out.println("Lampu sudah dalam kondisi redup");
		}
	}
	public int setSaklar(int saklar){
		return statusLampu = saklar;
	}
}
