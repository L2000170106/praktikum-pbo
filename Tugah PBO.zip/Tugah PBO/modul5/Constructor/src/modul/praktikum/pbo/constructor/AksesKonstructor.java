package modul.praktikum.pbo.constructor;

public class AksesKonstructor {
	public static void main(String[] args){
		ParamConstructor pc = new ParamConstructor("Anang Fahruddin Arbi", 2, "L200170106");
		pc.infoKu();
	}
}
