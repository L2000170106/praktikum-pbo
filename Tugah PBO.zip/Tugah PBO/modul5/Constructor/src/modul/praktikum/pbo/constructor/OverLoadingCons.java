package modul.praktikum.pbo.constructor;

import java.util.Date;

public class OverLoadingCons {
	int idUser ;
	String userName ;
	int level ;
	Date lastLogin ;
	public OverLoadingCons(){
	}
	public OverLoadingCons(int idUser, String userName){
		this.idUser = idUser ;
		this.userName = userName ;
	}
}
