package modul.praktikum.pbo.constructor;

public class ParamConstructor {
	String nama;
	int semester;
	String nim;
	public ParamConstructor(String namaKu, int SemesterKu, String nimKu){
		this.nama = namaKu ;
		this.nim = nimKu ;
		this.semester = SemesterKu ;
	}
	public void infoKu(){
		System.out.println(
				"======== Parameter Constructor ======== \n"+
				"Nama : "+nama+"\n"+
				"NIM : "+nim+"\n"+
				"Semester : "+semester+"\n"
				);
	}
}
