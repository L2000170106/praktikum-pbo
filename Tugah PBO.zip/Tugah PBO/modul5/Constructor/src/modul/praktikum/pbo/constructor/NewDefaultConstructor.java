package modul.praktikum.pbo.constructor;

public class NewDefaultConstructor {
	String nama ;
	String nim ;
	String alm;
	public NewDefaultConstructor(){
		this.nama = "Anang Fahruddin Arbi" ;
		this.nim = "L200170106" ;
		this.alm = "Jepara";
		
		System.out.println(
				"======== Default Constructor ======== \n"+
				"Nama = "+nama+"\n"+
				"NIM = "+nim+"\n"+
				"Alamat = "+alm+"\n"
				);
		
	}
}
