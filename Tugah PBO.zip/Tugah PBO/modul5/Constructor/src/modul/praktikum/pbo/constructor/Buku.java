package modul.praktikum.pbo.constructor;

public class Buku {
	String namaPengarang;
	String judulBuku;
	int tahunTerbit;
	int cetakanKe;
	double hargaJual;

	public Buku(){
		this.namaPengarang = "Anang Fahruddin Arbi";
		this.judulBuku = "Aku Adalah Aku Sendiri";
		this.tahunTerbit = 2020 ;
		this.cetakanKe = 2 ;
		this.hargaJual = 78000.00 ;
	}
	public void infoBuku(){
		System.out.println(
				"Nama Pengarang : "+namaPengarang+"\n"+
				"Judul Buku : "+judulBuku+"\n"+
				"Tahun Terbit : "+tahunTerbit+"\n"+
				"Cetakan : "+cetakanKe+"\n"+
				"Harga Jual : "+hargaJual+"\n"
				);
	}
	public static void main(String[]args){
		Buku ct = new Buku();
		ct.infoBuku();
	}
}
