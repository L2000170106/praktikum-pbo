package modul.praktikum.pbo.constructor;

public class DefaultConstructor {
	public DefaultConstructor(){
		System.out.println("default constructor");
	}
	// Bertujuan untuk memberikan nilai awal pada 'DefaultConstruct'
	public static void  main(String[] args){
		DefaultConstructor konstruktor = new DefaultConstructor();
	}
}
