package modul.praktikum.pbo.constructor;

public class ConstructCompiler {
	public static void main(String[] args){
		//Default Constructor
		NewDefaultConstructor print = new NewDefaultConstructor();
		
		//Parameter Constructor
		ParamConstructor cetak = new ParamConstructor("Anang Fahruddin", 2, "L200170106");
		cetak.infoKu();
	}
}
