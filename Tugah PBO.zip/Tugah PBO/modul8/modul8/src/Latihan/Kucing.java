package Latihan;

public class Kucing extends Pet{
	@Override
	public String perilaku(){
		return "Menyukai Ikan \nMeeooww..Meeooww";
	}
	
}
