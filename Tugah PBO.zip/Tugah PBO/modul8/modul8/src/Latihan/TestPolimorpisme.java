package Latihan;

public class TestPolimorpisme {
	public static void main(String[] args){
		Kucing k = new Kucing();
		Anjing a = new Anjing();
		k.beriNama("TOM");
		k.perilaku();
		System.out.println(k.panggilNama());
		System.out.println(k.perilaku());
		
		a.beriNama("BULL");
		a.perilaku();
		System.out.println(a.panggilNama());
		System.out.println(k.perilaku());
	}
}
