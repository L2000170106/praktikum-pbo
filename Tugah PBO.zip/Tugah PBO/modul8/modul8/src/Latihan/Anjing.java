package Latihan;

public class Anjing extends Pet {
	@Override
	public String perilaku(){
		return "Menyukai Daging dan Tulang \nGuk..Guk..Guk..";
	}
}
