package Tugas;

public class Bank {
	protected int rasio;
	protected void rasioBunga(int rasio){
		this.rasio = 2 ;
	}
	protected int rasioBunga(){
		return rasio;
	}
}
