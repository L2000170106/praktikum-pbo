package Tugas;

public class BankUmum extends Bank {
	protected int rasioBunga(){
		return 5 ;
		}
}
