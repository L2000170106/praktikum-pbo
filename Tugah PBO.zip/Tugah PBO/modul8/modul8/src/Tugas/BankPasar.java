package Tugas;

public class BankPasar extends BankUmum{
	protected int rasioBunga(){
		return 6 ;
		}
}
