package Tugas;

public class BankPribadi extends Bank{
	protected int rasioBunga(){
	return 4 ;
	}
}
