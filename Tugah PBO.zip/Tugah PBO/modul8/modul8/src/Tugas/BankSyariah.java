package Tugas;

public class BankSyariah extends BankUmum{
	protected int rasioBunga(){
		return 7 ;
		}
}
