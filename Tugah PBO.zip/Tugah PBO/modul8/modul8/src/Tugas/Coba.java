package Tugas;

public class Coba {
	public static void main(String[] args){
		Bank bpr = new Bank();
		System.out.println("Bank Pribadi = "+bpr.rasioBunga());
		Bank bu = new BankUmum();
		System.out.println("Bank Umum = "+bu.rasioBunga());
		Bank bps = new BankPasar();
		System.out.println("Bank Pasar = "+bps.rasioBunga());
		Bank bs = new BankSyariah();
		System.out.println("Bank Syariah = "+bs.rasioBunga());
		
		BankUmum bpsu = new BankPasar();
		System.out.println("Bank Pasar (Bank Umum) = "+bpsu.rasioBunga());
		BankUmum bsu = new BankSyariah();
		System.out.println("Bank Syariah (Bank Syariah) = "+bsu.rasioBunga());
	}
}
