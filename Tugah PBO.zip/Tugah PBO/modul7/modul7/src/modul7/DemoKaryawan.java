package modul7;

public class DemoKaryawan {
	public static void main(String[] args){
		Programmer tk1 = new Programmer();
		Programmer tk2 = new Programmer();
		Programmer tk3 = new Programmer();
		Programmer tk4 = new Programmer();
		Programmer tk5 = new Programmer();
		
		tk1.setNama("Anang");
		tk1.setNik("001");
		tk1.setJabatan("Ketua");
		tk1.setGaji(80000000);
		tk1.jamKerja();
		
		tk2.setNama("Fahruddin");
		tk2.setNik("002");
		tk2.setJabatan("Sekretaris");
		tk2.setGaji(60000000);
		tk2.jamKerja();
		
		tk3.setNama("Arbi");
		tk3.setNik("003");
		tk3.setJabatan("Bendahara");
		tk3.setGaji(50000000);
		tk3.jamKerja();
		
		tk4.setNama("Fulan");
		tk4.setNik("004");
		tk4.setJabatan("Anggota");
		tk4.setGaji(7000000);
		tk4.jamKerja();
		
		tk5.setNama("Fulanah");
		tk5.setNik("005");
		tk5.setJabatan("Anggota");
		tk5.setGaji(7000000);
		tk5.jamKerja();
		
		System.out.println(
				"Nama = "+tk1.getNama()+"\n"+
				"NIK = "+tk1.getNik()+"\n"+
				"Jabatan = "+tk1.getJabatan()+"\n"+
				"Jam kerja = "+tk1.jamKerja+"\n"+
				"Gaji Rp.= "+tk1.getGaji()+"\n"
				);
		
		System.out.println(
				"Nama = "+tk2.getNama()+"\n"+
				"NIK = "+tk2.getNik()+"\n"+
				"Jabatan = "+tk2.getJabatan()+"\n"+
				"Jam kerja = "+tk2.jamKerja+"\n"+
				"Gaji = Rp."+tk2.getGaji()+"\n"
				);
		
		System.out.println(
				"Nama = "+tk3.getNama()+"\n"+
				"NIK = "+tk3.getNik()+"\n"+
				"Jabatan = "+tk3.getJabatan()+"\n"+
				"Jam kerja = "+tk3.jamKerja+"\n"+
				"Gaji = Rp."+tk3.getGaji()+"\n"
				);
		
		System.out.println(
				"Nama = "+tk4.getNama()+"\n"+
				"NIK = "+tk4.getNik()+"\n"+
				"Jabatan = "+tk4.getJabatan()+"\n"+
				"Jam kerja = "+tk4.jamKerja+"\n"+
				"Gaji = Rp."+tk4.getGaji()+"\n"
				);
		
		System.out.println(
				"Nama = "+tk5.getNama()+"\n"+
				"NIK = "+tk5.getNik()+"\n"+
				"Jabatan = "+tk5.getJabatan()+"\n"+
				"Jam kerja = "+tk5.jamKerja+"\n"+
				"Gaji = Rp."+tk5.getGaji()+"\n"
				);
	}
}
