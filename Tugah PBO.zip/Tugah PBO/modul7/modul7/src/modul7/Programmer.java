package modul7;

public class Programmer extends Karyawan{
	int jamKerja = 8 ;
	public int jamKerja(){
		return jamKerja ;
	}
}
