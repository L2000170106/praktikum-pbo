package modul7;

public class EnkapsulasiApp {
	public static void main(String[] args){
		Enkapsulasi en = new Enkapsulasi();
		en.setNama("Anang Fahruddin Arbi");
		en.setNim("L200170106");
		en.setUmur(18);
		System.out.println(en.getNama());
		System.out.println(en.getNim());
		System.out.println(en.getUmur());
	}
}
