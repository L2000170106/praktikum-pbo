package modul7;

public class Karyawan {
	private String nama;
	private String nik ;
	private String jabatan ;
	private double gaji ;
	public String getNama(){
		return nama ;
	}
	public void setNama(String nama){
		this.nama = nama ;
	}
	
	public String getNik(){
		return nik ;
	}
	
	public void setNik(String nik){
		this.nik = nik ;
	}
	
	public String getJabatan(){
		return jabatan ;
	}
	
	public void setJabatan(String jabatan){
		this.jabatan = jabatan ;
	}
	
	public double getGaji(){
		return gaji ;
	}
	
	public void setGaji(double gaji){
		this.gaji = gaji ;
	}
	
}

