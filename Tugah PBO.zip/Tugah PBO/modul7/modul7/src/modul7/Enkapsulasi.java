package modul7;

public class Enkapsulasi {
	private String nama;
	private String nim;
	private int umur;
	public String getNama(){
		return nama ;
	}
	
	public void setNama(String nama){
		this.nama = nama ;
	}
	
	public String getNim(){
		return nim ;
	}
	
	public void setNim(String nim){
		this.nim = nim ;
	}
	
	public int getUmur(){
		return umur ;
	}
	
	public void setUmur(int umur){
		this.umur = umur ;
	}
	
}
