package Latihan;

public class Lingkaran extends MethodAbstrak{
	int r = 100; 
	@Override
	public int luas(){
		double luas = Math.PI * (r ^ 2);
		return (int)luas;
	}
	@Override
	public int keliling(){
		double keliling = Math.PI * (r * 2);
		return (int)keliling ;
	}
}
