package Latihan;

public class JajarGenjang extends MethodAbstrak {
	int alas = 20;
	int tinggi = 3;
	int miring = 2;
	@Override
	public int luas(){
		return (alas * tinggi) / 2 ;
	}
	@Override
	public int keliling(){
		return (alas + miring) * 2; 
	}
}
