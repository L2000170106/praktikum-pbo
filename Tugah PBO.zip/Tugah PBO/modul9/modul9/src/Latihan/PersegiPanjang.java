package Latihan;

public class PersegiPanjang extends MethodAbstrak{
	int p = 5;
	int l = 2;
	@Override
	public int luas(){
		return p * l ;
	}
	@Override
	public int keliling(){
		return 2 * (p + l);
	}
			
}
