package Latihan;

public class MethodMain {
	public static void main(String[] args){
		Persegi psg = new Persegi();
		PersegiPanjang pnj = new PersegiPanjang();
		JajarGenjang jjr = new JajarGenjang();
		Lingkaran lng =  new Lingkaran();
		SegiTiga sgt = new SegiTiga();
		
		System.out.println("Persegi");
		System.out.println("Keliling = " + psg.getKeliling());
		System.out.println("Luas = " + psg.getLuas());
		
		System.out.println("\nPersegi Panjang");
		System.out.println("Keliling = " + pnj.getKeliling());
		System.out.println("Luas = " + pnj.getLuas());
		
		System.out.println("\nJajar Genjang");
		System.out.println("Keliling = " + jjr.getKeliling());
		System.out.println("Luas = " + jjr.getLuas());
		
		System.out.println("\nLingkaran");
		System.out.println("Keliling = " + lng.getKeliling());
		System.out.println("Luas = " + lng.getLuas());
		
		System.out.println("\nSegi Tiga");
		System.out.println("Keliling = " + sgt.getKeliling());
		System.out.println("Luas = " + sgt.getLuas());
	}
}
