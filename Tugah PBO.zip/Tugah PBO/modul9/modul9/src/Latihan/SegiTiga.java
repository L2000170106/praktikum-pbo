package Latihan;

public class SegiTiga extends MethodAbstrak{
	int alas = 3 ;
	int tinggi = 4 ;
	int miring = 5 ;
	@Override
	public int luas(){
		return (alas * tinggi) / 2 ;
	}
	@Override
	public int keliling(){
		return alas + (miring * 2) ;
	}
}
