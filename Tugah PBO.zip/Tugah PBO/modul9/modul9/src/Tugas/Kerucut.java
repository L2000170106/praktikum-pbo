package Tugas;

public class Kerucut extends BangunRuang{
	int t = 10;
	int r = 100;
	int s = 2 ;
	@Override
	public int Volume(){
		double volume = (1/3) * Math.PI * (r ^ 2) * t ;
		return (int)volume;
	}
	@Override
	public int luasSelimut(){
		double luasSelimut = (Math.PI * (r ^ 2)) + (Math.PI * r *(r + s)) ;
		return (int)luasSelimut;
	}
}
