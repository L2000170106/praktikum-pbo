package Tugas;

public class Kubus extends BangunRuang{
	int s = 2;
	@Override
	public int Volume(){
		return s * s * s ;
	}
	@Override
	public int luasSelimut(){
		return 6 * s * s;
	}
}
