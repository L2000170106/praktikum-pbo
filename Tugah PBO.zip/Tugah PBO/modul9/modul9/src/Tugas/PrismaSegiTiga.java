package Tugas;

public class PrismaSegiTiga extends BangunRuang{
	int luasAlas = 30 ;
	int tinggi = 10 ;
	int luasTengah = 50 ;
	@Override
	public int Volume(){
		return luasAlas * tinggi ;
	}
	@Override
	public int luasSelimut(){
		return (2 * luasAlas) + ((3 * luasTengah)) ;
	}
}
