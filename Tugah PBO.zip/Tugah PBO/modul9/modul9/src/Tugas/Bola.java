package Tugas;

public class Bola extends BangunRuang{
	int r = 10;
	@Override
	public int Volume(){
		double volume = (4/3) * Math.PI * (r ^ 3) ;
		return (int)volume;
	}
	@Override
	public int luasSelimut(){
		double luasSelimut = 4 * Math.PI * (r ^ 2);
		return (int)luasSelimut;
	}
}
