package Tugas;

public abstract class BangunRuang {
	abstract int Volume();
	abstract int luasSelimut();
	
	int getVolume(){
		return Volume();
	}
	
	int getLuasSelimut(){
		return luasSelimut();
	}
}
