package Tugas;

public class Hasil {
	public static void main(String[] args){
		Balok blk = new Balok();
		Kubus kbs = new Kubus();
		Kerucut krc = new Kerucut();
		PrismaSegiTiga psm =  new PrismaSegiTiga();
		Bola bl = new Bola();
		
		System.out.println("Balok");
		System.out.println("Luas Permukaan = " + blk.luasSelimut());
		System.out.println("Volume" + blk.Volume());
		
		System.out.println("Kubus");
		System.out.println("Luas Permukaan = " + kbs.luasSelimut());
		System.out.println("Volume" + kbs.Volume());

		System.out.println("Kerucut");
		System.out.println("Luas Permukaan = " + krc.luasSelimut());
		System.out.println("Volume" + krc.Volume());
		
		System.out.println("Prisma Segi Tiga");
		System.out.println("Luas Permukaan = " + psm.luasSelimut());
		System.out.println("Volume" + psm.Volume());
		
		System.out.println("Bola");
		System.out.println("Luas Permukaan = " + bl.luasSelimut());
		System.out.println("Volume" + bl.Volume());
	}
}
