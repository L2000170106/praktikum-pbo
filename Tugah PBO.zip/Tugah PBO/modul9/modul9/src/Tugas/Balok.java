package Tugas;

public class Balok extends BangunRuang{
	int p = 5;
	int l = 3;
	int t = 2;
	@Override
	public int Volume(){
		return 4 * (p + l+ t) ;
	}
	@Override
	public int luasSelimut(){
		return 2 *((p * l) + (p * t) + (l * t));
	}
}
